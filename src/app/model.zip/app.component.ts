import { Component } from '@angular/core';

import './_content/app.less';
import './_content/modal.less';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'model';
}
